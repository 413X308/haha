import express from 'express';
import cors from 'cors';
import axios from 'axios';
import fs from 'fs';
import cryptoNode from 'crypto';
import { wrapper } from 'axios-cookiejar-support';
import { CookieJar } from 'tough-cookie';
import wasm from './loadWasm.js';
import fetch from 'node-fetch';

const app = express();
app.use(cors());
app.use(express.json());

const auth = "Basic RU1CUkVUQUlMV0VCOlNEMjM0ZGZnMzQlI0BGR0AzNHNmc2RmNDU4NDNm";
const BASE_URL = 'https://online.mbbank.com.vn';

function translateTransaction(tx) {
  return {
    posting_date: tx.postingDate || '',
    transaction_date: tx.transactionDate || '',
    account_number: tx.accountNo || '',
    credit_amount: tx.creditAmount || '',
    debit_amount: tx.debitAmount || '',
    currency: tx.currency || '',
    description: tx.description || '',
    additional_description: tx.addDescription || '',
    available_balance: tx.availableBalance || '',
    beneficiary_account: tx.beneficiaryAccount || '',
    reference_number: tx.refNo || '',
    beneficiary_name: tx.benAccountName || '',
    bank_name: tx.bankName || '',
    beneficiary_account_number: tx.benAccountNo || '',
    due_date: tx.dueDate || '',
    document_id: tx.docId || '',
    transaction_type: tx.transactionType || '',
    location: tx.pos || '',
    tracing_type: tx.tracingType || ''
  };
}

async function getAllTransactions(payload, accountNo, fromDate, toDate) {
  const url = `${BASE_URL}/api/retail-transactionms/transactionms/get-account-transaction-history`;

  const headers = {
    accept: 'application/json, text/plain, */*',
    'accept-encoding': 'gzip, deflate, br, zstd',
    'accept-language': 'vi-VN,vi;q=0.9',
    app: 'MB_WEB',
    authorization: auth,
    'content-type': 'application/json; charset=UTF-8',
    deviceid: payload.deviceIdCommon,
    origin: BASE_URL,
    referer: `${BASE_URL}/information-account/source-account`,
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    refno: payload.refNo,
    'x-request-id': payload.refNo,
  };

  const data = {
    accountNo,
    deviceIdCommon: payload.deviceIdCommon,
    fromDate,
    refNo: payload.refNo,
    sessionId: payload.sessionId,
    toDate,
  };

  const response = await axios.post(url, data, { headers });
  return response.data;
}

async function solveCaptcha(base64Image) {
  const url = "http://103.72.96.214:8277/api/captcha/mbbank";
  const headers = { "Content-Type": "application/json" };
  const payload = JSON.stringify({ base64: base64Image });

  const response = await fetch(url, {
    method: "POST",
    headers,
    body: payload,
  });

  if (!response.ok) throw new Error("Captcha API error");
  const result = await response.json();

  if (result.status !== "success") throw new Error("Captcha solve failed");
  return result.captcha;
}

async function loginMBBank(username, password) {
  const deviceIdCommon = "4ncebo1c-mbib-0000-0000-2025052623303333";
  const refNo = `${username}-${Date.now()}`;
  console.log(`Generated refNo: ${refNo}`);

  const jar = new CookieJar();
  const client = wrapper(axios.create({ jar }));

  // Tải wasm nếu chưa có
  if (!fs.existsSync("./main.wasm")) {
    const response = await client.get(`${BASE_URL}/assets/wasm/main.wasm`, { responseType: "stream" });
    await new Promise((resolve, reject) => {
      const writer = fs.createWriteStream("main.wasm");
      response.data.pipe(writer);
      writer.on("finish", resolve);
      writer.on("error", reject);
    });
  }

  // Lấy cookie session bằng truy cập trang login
  await client.get(`${BASE_URL}/pl/login`);

  // Lấy captcha image
  const captchaResponse = await client.post(
    `${BASE_URL}/api/retail-web-internetbankingms/getCaptchaImage`,
    { refNo, deviceIdCommon, sessionId: "" },
    {
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
        Authorization: auth,
        Accept: "application/json, text/plain, */*",
        App: "MB_WEB",
        Referer: `${BASE_URL}/pl/login`,
        Origin: BASE_URL,
      }
    }
  );

  const base64Image = captchaResponse.data.imageString;
  const captcha = await solveCaptcha(base64Image);

  // Tạo payload đăng nhập
  const loginPayload = {
    userId: username,
    password: cryptoNode.createHash("md5").update(password).digest("hex"),
    captcha,
    ibAuthen2faString: "c722fa8dd6f5179150f472497e022ba0",
    sessionId: null,
    refNo,
    deviceIdCommon
  };

  // Mã hóa payload bằng wasm
  const dataEnc = await wasm(fs.readFileSync("./main.wasm"), loginPayload, "0");

  // Gửi request login
  const loginRes = await client.post(
    `${BASE_URL}/api/retail_web/internetbanking/v2.0/doLogin`,
    { dataEnc },
    {
      headers: {
        accept: "application/json, text/plain, */*",
        "accept-language": "vi-VN,vi;q=0.9",
        Origin: 'https://online.mbbank.com.vn',
        Referer: 'https://online.mbbank.com.vn/pl/login',
        'If-Match': '*',
        app: "MB_WEB",
        authorization: auth,
        "content-type": "application/json; charset=UTF-8",
        "elastic-apm-traceparent":
          "00-2f346e62082f1d9b71c22fb4ae20760f-2f2c02091e76c71f-01",
        refno: refNo,
        Cookie: await jar.getCookieString(BASE_URL),
        "sec-ch-ua":
          '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "x-request-id": refNo,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      },
    }
  );

  const sessionId = loginRes.data.sessionId;

  if (!sessionId) throw new Error("Login failed: no sessionId returned");

  return { refNo, sessionId, deviceIdCommon };
}

app.post('/api/check-balance', async (req, res) => {
  const { account_no, from_date, to_date, username, password } = req.body;

  if (!account_no || !username || !password) {
    return res.status(400).json({ status: 'error', message: 'Missing account_no, username or password' });
  }

  let fromDate = from_date;
  let toDate = to_date;

  const today = new Date();
  if (!toDate) toDate = `${today.getDate().toString().padStart(2, '0')}/${(today.getMonth() + 1).toString().padStart(2, '0')}/${today.getFullYear()}`;
  if (!fromDate) fromDate = `01/${(today.getMonth() + 1).toString().padStart(2, '0')}/${today.getFullYear()}`;

  try {
    // Login lấy session
    const payload = await loginMBBank(username, password);

    // Lấy lịch sử giao dịch
    const rawData = await getAllTransactions(payload, account_no, fromDate, toDate);
    let txList = [];

    if (rawData.transactionHistoryList) {
      txList = rawData.transactionHistoryList;
    } else if (rawData.data?.transactionHistoryList) {
      txList = rawData.data.transactionHistoryList;
    }

    const translated = txList.map(translateTransaction);
    res.json({ status: 'success', data: translated });

  } catch (err) {
    console.error("❌ Lỗi:", err.message);
    res.status(500).json({ status: 'error', message: err.message || 'Lỗi khi xử lý' });
  }
});

app.listen(8277, () => {
  console.log('🚀 Server đang chạy tại http://localhost:8277/api/check-balance');
});
